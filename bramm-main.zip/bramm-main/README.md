# Dockerisation

Basé sur [Gist clandestine8](https://gist.github.com/clandestine8/48eb01d49a5ef919b0632aa07e41c860) et utilisation de [ce Dockerfile](https://cours.brosseau.ovh/tp/ops/deployer-laravel-docker.html)
